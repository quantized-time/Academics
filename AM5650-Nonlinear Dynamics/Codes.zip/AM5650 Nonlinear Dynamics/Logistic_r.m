% Logistic Map Analysis in MATLAB
clear; clc; close all;

% Parameters
r = input('Enter the value of r: '); % Growth rate parameter
time_steps = 100; % Number of iterations
x0 = 0.500031; % Initial population fraction

% Initialize array for x values
x = zeros(1, time_steps);
x(1) = x0; % Set initial condition

% Iterate the logistic map equation
for t = 2:time_steps
    x(t) = r * x(t-1) * (1 - x(t-1)); % Logistic map equation
end

% Plot x vs. t
figure;
plot(1:time_steps, x, 'bo-', 'LineWidth', 1.5, 'MarkerSize', 4);
xlabel('Time step (t)');
ylabel('Population fraction (x)');
title(['Logistic Map: r = ', num2str(r)]);
grid on;
