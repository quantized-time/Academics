% Lorenz System Solver and Lyapunov Exponent Calculation
clear; clc;

% Parameters
sigma = 10;
rho = 30;
beta = 8/3;

% Time span and options for ode45
tspan = [0 100]; 
options = odeset('RelTol',1e-9,'AbsTol',1e-9);  % High precision

% Initial conditions
initial_conditions =[1,1,1];% [sqrt(beta*(rho-1)),sqrt(beta*(rho-1)),rho-1];%[-20, -20 50];

% Solving Lorenz equations for original system
[t, sol] = ode45(@(t, Y) lorenz_eqns(t, Y, sigma, rho, beta), tspan, initial_conditions, options);

% Extracting x, y, z
x = sol(:, 1);
y = sol(:, 2);
z = sol(:, 3);

% Plotting x, y, z vs t
figure;
subplot(3,1,1);
plot(t, x);
title('x vs t');
xlabel('t');
ylabel('x');

subplot(3,1,2);
plot(t, y);
title('y vs t');
xlabel('t');
ylabel('y');

subplot(3,1,3);
plot(t, z);
title('z vs t');
xlabel('t');
ylabel('z');

figure;
plot3(x,y,z,'.')

% Lyapunov Exponent Calculation
epsilon = 1e-8;  % Perturbation size
perturbed_conditions = initial_conditions + epsilon * rand(1, 3);  % Perturbed initial conditions
d0 = norm(perturbed_conditions - initial_conditions);  % Initial distance

% Solving for perturbed system using the same time span
[~, sol_perturbed] = ode45(@(t, Y) lorenz_eqns(t, Y, sigma, rho, beta), tspan, perturbed_conditions, options);

% Interpolating perturbed solution to match the time points of the original solution
sol_interp = deval(ode45(@(t, Y) lorenz_eqns(t, Y, sigma, rho, beta), tspan, perturbed_conditions, options), t);

% Compute the separation between trajectories at each time step
d = sqrt((sol_interp(1,:) - sol(:,1)').^2 + (sol_interp(2,:) - sol(:,2)').^2 + (sol_interp(3,:) - sol(:,3)').^2);

% Calculate Lyapunov exponent
t=t';
lyap_exp = mean(log(d ./ d0) ./ (t + epsilon));  % Averaging over time

% Display the Lyapunov exponent
fprintf('Lyapunov Exponent: %f\n', lyap_exp);

% Lorenz Equations Function
function dYdt = lorenz_eqns(~, Y, sigma, rho, beta)
    x = Y(1);
    y = Y(2);
    z = Y(3);

    dxdt = sigma * (y - x);
    dydt = x * (rho - z) - y;
    dzdt = x * y - beta * z;

    dYdt = [dxdt; dydt; dzdt];
end

