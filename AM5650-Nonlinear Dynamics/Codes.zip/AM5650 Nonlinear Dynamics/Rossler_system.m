%% Rossler system
clear all
global a b c
a =0.4; b=0.4; c=1.5;
xeq1=[0;0;0];xeq2=[c-a*b;-(c-a*b)/a;(c-a*b)/a];
A=[[0 -1 -1];[1 a 0];[b 0 -c]];
B=[[0 -1 -1];[1 a 0];[b+xeq2(3) 0 -c+xeq2(1)]];
[T V]=eigs(A);
[T1 V1]=eigs(B);
x0=[2.427;0.1284;3.36533];%0.1*T(1,:)+xeq1'; 
[t,y] = ode45(@Rossler,[0 200],x0);
figure(1)
plot3(y(:,1), y(:,2), y(:,3));hold on
plot3(x0(1),x0(2),x0(3),'ko')
plot3(xeq1(1),xeq1(2),xeq1(3),'ro')
plot3([xeq1(1) T(1,1)*1],[xeq1(2) T(1,2)*1],[xeq1(3) T(1,3)*1],'r-')
plot3(xeq2(1),xeq2(2),xeq2(3),'ro')
plot3([xeq2(1) +T1(3,1)*1+xeq2(1)],[xeq2(2) +T1(3,2)*1+xeq2(2)],[xeq2(3) +T1(3,3)*1+xeq2(3)],'r-')
txt=['The Rossler attractor for a=',num2str(a),' b=',num2str(b),' c=',num2str(c)];
title(txt);
xlabel('x');
ylabel('y');
zlabel('z');
grid
axis square
axis equal
hold off
%view([90 90])
figure(2)
subplot(3,1,1);
plot(t,y(:,3));ylabel('z')
subplot(3,1,2);
plot(t,y(:,2));ylabel('y')
subplot(3,1,3);
plot(t,y(:,1));xlabel('t');ylabel('x') 

%% Rossler system

function dydt = Rossler(t,y)
global a b c

dydt = [-y(2)-y(3); y(1)+a*y(2); b*y(1)-c*y(3)+y(1)*y(3)];


end