% Bifurcation Diagram for the Logistic Map
clear; clc; close all;

% Define range of r values
r_min = 3.0;   % Minimum r value
r_max = 4.0;   % Maximum r value
num_r = 10000;  % Number of r values to compute

% Define number of iterations and transient cutoff
time_steps = 500;     % Total iterations per r value
transient = 400;      % Transient iterations to discard

% Initial condition
x0 = 0.5;  

% Generate r values
r_values = linspace(r_min, r_max, num_r);
x_values = [];

% Compute bifurcation diagram
for i = 1:num_r
    r = r_values(i);
    x = x0;
    
    % Iterate logistic map (discard transient points)
    for t = 1:transient
        x = r * x * (1 - x);
    end
    
    % Store steady-state values
    steady_state_x = zeros(1, time_steps - transient);
    for t = 1:(time_steps - transient)
        x = r * x * (1 - x);
        steady_state_x(t) = x;
    end
    
    % Append results for plotting
    x_values = [x_values; repmat(r, length(steady_state_x), 1), steady_state_x'];
end

% Plot bifurcation diagram
figure;
plot(x_values(:,1), x_values(:,2), 'k.', 'MarkerSize', 1);
xlabel('r');
ylabel('Steady-state x');
title('Bifurcation Diagram of the Logistic Map');
xlim([r_min, r_max]);
ylim([0, 1]);
grid on;
